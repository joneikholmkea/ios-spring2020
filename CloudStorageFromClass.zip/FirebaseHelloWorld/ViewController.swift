//
//  ViewController.swift
//  FirebaseHelloWorld
//
//  Created by Jon Eikholm on 28/02/2020.
//  Copyright © 2020 Jon Eikholm. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var headline: UITextView!
    @IBOutlet weak var body: UITextView!
    var rowNumber = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // use rowNumber to get the right Note object
        let note = CloudStorage.getNoteAt(index: rowNumber)
        headline.text = note.head
        body.text = note.body
        if note.image != "empty"{
           CloudStorage.downloadImage(name: note.image, vc: self)
        }else {
            print("note is empty")
        }
    }

    @IBAction func btnClicked(_ sender: UIButton) {
        CloudStorage.updateNote(index: 0, head: "new headline", body: "new body")
    }
    
    @IBAction func downloadBtnPressed(_ sender: UIButton) {
       // CloudStorage.downloadImage(name: images.randomElement()!, vc:self) // calls static method
        // and prints a message
    }
}

